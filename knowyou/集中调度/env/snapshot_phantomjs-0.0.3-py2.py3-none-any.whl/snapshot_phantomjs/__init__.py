# flake8: noqa
from snapshot_phantomjs._version import __author__, __version__
